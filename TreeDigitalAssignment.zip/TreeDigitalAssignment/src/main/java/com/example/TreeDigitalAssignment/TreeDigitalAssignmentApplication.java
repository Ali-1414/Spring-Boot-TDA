package com.example.TreeDigitalAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreeDigitalAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TreeDigitalAssignmentApplication.class, args);
	}

}
